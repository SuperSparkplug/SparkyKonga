//Sparky Konga by Jordan Sparks

//Bongo Clap - Particle Burst Script
//Controls the particle bursts within the blue cube that uses the Bongo's microphone to sense claps
//Mic value gets data from PD's OSC Messages of the microphone and compares it to filter value. If greater than filter, it triggers
//Particle Burst can also be triggered with the W Key
//Alt function is controlled by pressing Bongo's START button (JoystickButton9) or the S key.
//Uses Jorge Garcia's UnityOSC Library to sense the OSC messages sent from Pure Data.
//A copy of the UnityOSC Library tailored to Sparky Konga is included in the Unity files.
//Special thanks to Jorge Garcia for developing the entire UnityOSC library (https://github.com/jorgegarcia)

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityOSC;

public class BongoClapScript : MonoBehaviour
{
	
	public int burst = 500;
	public AudioClip clap;
	public AudioClip clap2;
	public bool alt;
	public int filter = 14;	// Use this variable to control the sound threshold/sensitivity
	private Dictionary<string, ServerLog> servers;

	
	/*public Light flash;
	private float lerpTime = 0.5f;
	private float i = 0;*/
	
	// Use this for initialization
	void Start ()
	{
		OSCHandler.Instance.Init ();
		servers = new Dictionary<string, ServerLog> (); 
		particleSystem.emissionRate = 0;
		StartCoroutine (BongoClap()); //Run BongoClap IEnumerator Coroutine
	}
	
	/*public void OSCMessageReceived(OSC.NET.OSCMessage message){
	string address = message.Address;
	ArrayList args = message.Values;
	}*/
	
	void Update () {
		//Quit
		if(Input.GetKey(KeyCode.Escape)) {
			Application.Quit();
		}
	}
	
	// IEnumerator acts like an update function
	IEnumerator BongoClap ()	{
		while (true) {
			yield return null; //Put yield return null here to stop Unity from crashing
			
			// This function controls the alt function when the S key or the START button is pressed to trigger alternate sounds
			if ((Input.GetKeyDown (KeyCode.JoystickButton9) || Input.GetKeyDown (KeyCode.S))) {
				alt = !alt;
			}
     
			if ((Input.GetKeyDown (KeyCode.JoystickButton9) || Input.GetKeyDown (KeyCode.S)) && alt == true) {
				alt = alt;
			}
     		
			// The following uses Jorge Garcia's UnityOSC library
			OSCHandler.Instance.UpdateLogs ();
			servers = OSCHandler.Instance.Servers;
     
			foreach (var item in servers) {
				// If we have received at least one packet,
				// show the last received from the log in the Debug console
				if (item.Value.log.Count > 0) {
					int lastPacketIndex = item.Value.packets.Count - 1;
     
					Debug.Log (String.Format ("SERVER: {0} ADDRESS: {1} VALUE 0: {2}",
    											item.Key, // Server name
    											item.Value.packets [lastPacketIndex].Address, // OSC address
    											item.Value.packets [lastPacketIndex].Data [0].ToString ())); //First data value
     
					int mic = (int)item.Value.packets [lastPacketIndex].Data [0];
					Debug.Log ("microphone" + mic); //Allows you to see the microphone level values in the console for testing purposes
     
					//Triggers Particles, sounds, and sets buffer for mic values
					if (mic >= filter && alt == false) {
						particleSystem.Emit (burst);
						audio.PlayOneShot (clap);
					}
     
					if (mic >= filter && alt == true) {
						particleSystem.Emit (burst);
						audio.PlayOneShot (clap2);
					}
     
					if ((Input.GetKeyDown (KeyCode.JoystickButton0)) || (Input.GetKeyDown (KeyCode.JoystickButton1)) || (Input.GetKeyDown (KeyCode.JoystickButton2)) || (Input.GetKeyDown (KeyCode.JoystickButton3))) {
						yield return new WaitForSeconds(0.25f);
				}
				}
     
					if ((Input.GetKeyDown (KeyCode.W) && alt == false)) {
						particleSystem.Emit (burst);
						audio.PlayOneShot (clap);
					}
     
					if (Input.GetKeyDown (KeyCode.W) && alt == true) {
						particleSystem.Emit (burst);
						audio.PlayOneShot (clap2);
					}
     
				}
			}
     
		}
     
	}

