//Sparky Konga by Jordan Sparks

//Right Bongo - Light Flash Script
//Controls the brief flash of light from within the green cube as a result of hitting the right bongo.
//Right Bongo is JoystickButton0 & JoystickButton1.
//You can also activate it with the D Key for testing.

using UnityEngine;
using System.Collections;

public class LightFlashR : MonoBehaviour {
	
	public float maxDist = 10.0f;
	public float speed = 40.0f;
	private float timer = 0.0f;
	public float flashTime = 0.2f;
     
	
	// Use this for initialization
	void Start () {
		light.range = 0;
	}
	
	// Update is called once per frame
	void Update () {

	if(Input.GetKeyDown(KeyCode.D) || (Input.GetKeyDown(KeyCode.JoystickButton0)) || (Input.GetKeyDown(KeyCode.JoystickButton1))) {
         timer = 0.0f;
       }
       if (timer <= flashTime)   {
         light.range = maxDist * Mathf.PingPong(timer / flashTime * 2.0f, 1.0f);
         timer += Time.deltaTime;
       }
	}
     
    }
	
