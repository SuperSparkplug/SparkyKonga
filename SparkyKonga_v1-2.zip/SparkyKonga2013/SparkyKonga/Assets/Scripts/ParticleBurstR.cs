//Sparky Konga by Jordan Sparks

///Right Bongo - Particle Burst Script
//Controls the brief flash of light from within the green cube as a result of hitting the right bongo.
//Right Bongo is JoystickButton0 & JoystickButton1.
//You can also activate it with the D Key for testing.

using UnityEngine;
using System.Collections;

public class ParticleBurstR : MonoBehaviour {
   	public int burst = 500; 
   	public AudioClip bongo;
	public AudioClip bongo2;
	public bool alt;
	
void Start () {
    // You can use particleSystem emmission rate is set to 0 by
	particleSystem.emissionRate = 0;
	alt = false;
}
     
void Update () {
		
		// This function controls the alt function when the S key or the START button is pressed to trigger alternate sounds
		if (Input.GetKeyDown(KeyCode.JoystickButton9) || Input.GetKeyDown (KeyCode.S))	{
			alt = !alt;			
		}
		
		if (Input.GetKeyDown (KeyCode.JoystickButton9) || Input.GetKeyDown (KeyCode.S) && alt == true)	{
			alt = alt;
		}
	//The following controls the particle bursts & sounds	
    if ((Input.GetKeyDown( (KeyCode.JoystickButton0)) || (Input.GetKeyDown(KeyCode.JoystickButton1)) || (Input.GetKeyDown(KeyCode.D))) && alt == false) {
    	
			audio.PlayOneShot (bongo);
			particleSystem.Emit(burst);
			
    }
		
		if ((Input.GetKeyDown( (KeyCode.JoystickButton0)) || (Input.GetKeyDown(KeyCode.JoystickButton1)) || (Input.GetKeyDown(KeyCode.D))) && alt == true) {
    	
			audio.PlayOneShot (bongo2);
			particleSystem.Emit(burst);
			
    }
}

}
