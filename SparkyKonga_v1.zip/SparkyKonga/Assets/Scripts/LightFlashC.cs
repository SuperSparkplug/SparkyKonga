//Sparky Konga by Jordan Sparks

//Microphone Clap - Light Flash Script
//Controls the small flash of right within the blue cube that uses the Bongo's microphone to senses claps
//Mic value gets data from PD's OSC Messages of the microphone and compares it to filter value. If greater than filter, it triggers
//Can also be triggered with the W Key
//Alt function is controlled by pressing Bongo's START button (JoystickButton9) or the S key.
//Uses Jorge Garcia's UnityOSC Library to sense the OSC messages sent from Pure Data.
//A copy of the UnityOSC Library tailored to Sparky Konga is included in the Unity files.
//Special thanks to Jorge Garcia for developing the entire UnityOSC library (https://github.com/jorgegarcia)

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityOSC;

public class LightFlashC : MonoBehaviour {
	
	public float maxDist = 10.0f;
	private float timer = 0.0f;
	public float flashTime = 0.1f;
	
	public int filter = 14;
	private Dictionary<string, ServerLog> servers;
     
	
	// Use this for initialization
	void Start () {
	   // OSCHandler.Instance.Init();
	   // servers = new Dictionary<string, ServerLog>(); 
		light.range = 0;
		StartCoroutine (ClapLight()); //Run BongoClap IEnumerator Coroutine
	}
	
	// IEnumerator acts like an update function
	IEnumerator ClapLight ()	{
		while (true) {
			yield return null; //Put yield return null here to stop Unity from crashing
		
		OSCHandler.Instance.UpdateLogs();
		servers = OSCHandler.Instance.Servers;
		
	    foreach( KeyValuePair<string, ServerLog> item in servers )
		{
			// If we have received at least one packet,
			// show the last received from the log in the Debug console
			if(item.Value.log.Count > 0) 
			{
				int lastPacketIndex = item.Value.packets.Count - 1;
			
				Debug.Log(String.Format("SERVER: {0} ADDRESS: {1} VALUE 0: {2}", 
				                                    item.Key, // Server name
				                                    item.Value.packets[lastPacketIndex].Address, // OSC address
				                                    item.Value.packets[lastPacketIndex].Data[0].ToString())); //First data value
		
			    int mic = (int) item.Value.packets[lastPacketIndex].Data[0];
				Debug.Log("microphone" + mic);
			
				//Triggers Particles, sounds, and sets buffer for mic values
				if (mic >= filter) {
					  timer = 0.0f;
      			 }
       			if (timer <= flashTime)   {
        		 light.range = maxDist * Mathf.PingPong(timer / flashTime * 2.0f, 1.0f);
        			 timer += Time.deltaTime;
					}
				
					if ((Input.GetKeyDown (KeyCode.JoystickButton0)) || (Input.GetKeyDown (KeyCode.JoystickButton1)) || (Input.GetKeyDown (KeyCode.JoystickButton2)) || (Input.GetKeyDown (KeyCode.JoystickButton3))) {
						yield return new WaitForSeconds(0.3f);
				}
			}
			
			if (Input.GetKeyDown (KeyCode.W))	{
				  timer = 0.0f;
      			 }
       			if (timer <= flashTime)   {
        		 light.range = maxDist * Mathf.PingPong(timer / flashTime * 2.0f, 1.0f);
        			 timer += Time.deltaTime;
					}
			}
				
			
	    }
		
   	 }
}
