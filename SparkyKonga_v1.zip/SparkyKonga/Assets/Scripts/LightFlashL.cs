//Sparky Konga by Jordan Sparks

//Left Bongo - Light Flash Script
//Controls the brief flash of light from within the red cube as a result of hitting the left bongo.
//Left Bongo is JoystickButton2 & JoystickButton3.
//You can also activate it with the A Key for testing.

using UnityEngine;
using System.Collections;


public class LightFlashL : MonoBehaviour {
	
	public float maxDist = 10.0f;
	public float speed = 40.0f;
	private float timer = 0.0f;
	public float flashTime = 0.2f;
     
	
	// Use this for initialization
	void Start () {
		light.range = 0;
	}
	
	// Update is called once per frame
	void Update () {

	if((Input.GetKeyDown(KeyCode.A)) || (Input.GetKeyDown(KeyCode.JoystickButton2)) || (Input.GetKeyDown(KeyCode.JoystickButton3))) {
         timer = 0.0f;
       }
       if (timer <= flashTime)   {
         light.range = maxDist * Mathf.PingPong(timer / flashTime * 2.0f, 1.0f);
         timer += Time.deltaTime;
       }
	}
     
    }
	
