//Sparky Konga by Jordan Sparks

//Left Bongo - Particle Burst Script
//Controls the brief flash of light from within the red cube as a result of hitting the left bongo.
//Left Bongo is JoystickButton2 & JoystickButton3.
//You can also activate it with the A Key for testing.

using UnityEngine;
using System.Collections;

public class ParticleBurstL : MonoBehaviour {
   	public int burst = 500; 
	public AudioClip bongo;
	public AudioClip bongo2;
	public bool alt;
	
void Start () {
    // You can use particleSystem emmission rate is set to 0 by
	particleSystem.emissionRate = 0;
	alt = false;
}
     
void Update () {
		
		// This function controls the alt function when the S key or the START button is pressed to trigger alternate sounds
		if (Input.GetKeyDown (KeyCode.JoystickButton9) || Input.GetKeyDown (KeyCode.S))	{
			alt = !alt;			
		}
		
		if (Input.GetKeyDown (KeyCode.JoystickButton9) || Input.GetKeyDown (KeyCode.S) && alt == true)	{
			alt = alt;
		}
		
	//The following controls the particle bursts & sounds	
    if ((Input.GetKeyDown((KeyCode.JoystickButton2)) || (Input.GetKeyDown(KeyCode.JoystickButton3)) || (Input.GetKeyDown(KeyCode.A))) && (alt == false)) {
    		
			particleSystem.Emit(burst);
			audio.PlayOneShot(bongo);
    }
		
		if ((Input.GetKeyDown((KeyCode.JoystickButton2)) || (Input.GetKeyDown(KeyCode.JoystickButton3)) || (Input.GetKeyDown(KeyCode.A))) && (alt == true)) {
    		
			particleSystem.Emit(burst);
			audio.PlayOneShot(bongo2);
    }
}

}
